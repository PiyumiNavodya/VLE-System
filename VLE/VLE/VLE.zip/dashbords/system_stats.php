<?php
    session_start();
    if(!isset($_SESSION["role"]) || $_SESSION["role"] != "admin") {
        header("Location: ../index.php");
        exit;
    }
    include "../php/sys.php";
    check_users();
    if(!is_active($_SESSION["username"])){
        header("Location: ../index.php?error=session_expired");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Stats | VLE</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="page-container">
        <!-- Navigation -->
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <i class="fas fa-chart-bar"></i>
                    <span>VLE System</span>
                </div>
                <div class="nav-items">
                    <div class="user-profile">
                        <div class="user-avatar">AD</div>
                        <span>Admin</span>
                    </div>
                    <a href="#" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <div class="header-section">
                <h2><i class="fas fa-chart-line"></i> System Statistics</h2>
                <div class="card-actions">
                    <button class="action-btn">
                        <i class="fas fa-download"></i> Export Data
                    </button>
                </div>
            </div>

            <div class="dashboard-grid">
                <!-- User Stats Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-users green-icon"></i> User Statistics</h3>
                    </div>
                    <div class="gpa-display">
                        <div class="gpa-circle">
                            <svg class="progress-ring" width="120" height="120">
                                <circle class="progress-ring-circle" stroke-width="8" fill="transparent" r="52" cx="60" cy="60" stroke-dasharray="326.56" stroke-dashoffset="65.312" />
                            </svg>
                            <div class="gpa-value">
                            <?php
                            $sql="select count(ID) as user_count from users;";
                            $result=$conn->query($sql);
                            while($row=$result->fetch_assoc()){
                                echo $row["user_count"];
                            }
                            ?>
                            </div>
                        </div>
                        <div class="gpa-details">
                            <div class="detail-item">
                                <span class="detail-label">Students</span>
                                <span class="detail-value">
                                <?php
                                $sql="select count(ID) as student_count from users where role='student';";
                                $result=$conn->query($sql);
                                while($row=$result->fetch_assoc()){
                                    echo $row["student_count"];
                                }
                                ?>
                                </span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Instructors</span>
                                <span class="detail-value">
                                <?php
                                $sql="select count(ID) as staff_count from users where role='staff';";
                                $result=$conn->query($sql);
                                while($row=$result->fetch_assoc()){
                                    echo $row["staff_count"];
                                }
                                ?>   
                                </span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Admins</span>
                                <span class="detail-value">
                                <?php
                                $sql="select count(ID) as admin_count from users where role='admin';";
                                $result=$conn->query($sql);
                                while($row=$result->fetch_assoc()){
                                    echo $row["admin_count"];
                                }
                                ?>
                                </span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Active Today</span>
                                <span class="detail-value">
                                <?php
                                $sql="select count(ID) as active_count from users where active='yes';";
                                $result=$conn->query($sql);
                                while($row=$result->fetch_assoc()){
                                    echo $row["active_count"];
                                }
                                ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- System Health Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-heartbeat red-icon"></i> System Health</h3>
                    </div>
                    <div class="assignment-list">
                        <div class="assignment-item">
                            <div class="assignment-details">
                                <h3>Server Uptime</h3>
                                <p>99.98% over last 30 days</p>
                            </div>
                            <span class="detail-value">Excellent</span>
                        </div>
                        <div class="assignment-item">
                            <div class="assignment-details">
                                <h3>Storage Usage</h3>
                                <p>45.2 GB of 100 GB used</p>
                            </div>
                            <span class="detail-value">45%</span>
                        </div>
                        <div class="assignment-item urgent">
                            <div class="assignment-details">
                                <h3>Backup Status</h3>
                                <p>Last backup: 2 days ago</p>
                            </div>
                            <button class="action-btn">
                                <i class="fas fa-sync"></i> Run Now
                            </button>
                        </div>
                    </div>
                </div>

        </main>

        <!-- Footer -->
        <footer class="footer">
            <div class="footer-container">
                <p>&copy; 2023 Virtual Learning Environment</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </footer>
    </div>
</body>
</html>