<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | VLE</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Password Reset Specific Styles */
        .password-reset-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 120px);
            padding: 2rem;
        }
        
        .password-reset-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            padding: 2.5rem;
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .password-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .password-header h2 {
            color: var(--primary-color);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
        }
        
        .password-header p {
            color: var(--text-secondary);
            font-size: 0.95rem;
        }
        
        .password-reset-form {
            margin-top: 1.5rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--text-primary);
            font-size: 0.9rem;
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-with-icon i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--icon-color);
        }
        
        .input-with-icon input {
            width: 100%;
            padding: 0.75rem 1rem 0.75rem 2.75rem;
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius-sm);
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }
        
        .input-with-icon input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(106, 90, 205, 0.2);
        }
        
        .toggle-password {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--icon-color);
            cursor: pointer;
            padding: 0.25rem;
            font-size: 1rem;
        }
        
        .toggle-password:hover {
            color: var(--primary-color);
        }
        
        .submit-btn {
            width: 100%;
            background-color: var(--primary-color);
            color: var(--white);
            border: none;
            padding: 0.75rem;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            transition: background-color 0.3s;
            margin-top: 0.5rem;
        }
        
        .submit-btn:hover {
            background-color: var(--primary-dark);
        }
        
        @media (max-width: 576px) {
            .password-reset-card {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
        <!-- Navigation (same as other pages) -->
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <i class="fas fa-calendar-alt"></i>
                    <span>VLE System</span>
                </div>
                <div class="nav-items">
                    <div class="user-profile">
                        <div class="user-avatar">
                            <?php
                            
                            $user_name=$_SESSION["role"];
                            echo $user_name;
                            ?></div>
                        <span>
                            <?php
                            $user_name=$_SESSION["username"];
                            echo $user_name;
                            ?>
                        </span>
                    </div>
                    <a href="#" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <div class="password-reset-container">
                <div class="password-reset-card">
                    <div class="password-header">
                        <h2><i class="fas fa-lock"></i> Reset Password</h2>
                        <p>Enter your current and new password to update</p>
                    </div>
                    
                    <form class="password-reset-form" action="../php/reset.php" method="post">
                        <p style=color:red ><?php
                            if(isset($_GET['pw_reset_error'])){
                                echo $_GET['pw_reset_error'];
                            }
                            ?>
                        </p>
                        <div class="form-group">
                            <label for="current-password">Current Password</label>
                            <div class="input-with-icon">
                                <i class="fas fa-key"></i>
                                <input type="password" id="current-password" placeholder="Enter current password" name="current" required>
                                
                                <button type="button" class="toggle-password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="new-password">New Password</label>
                            <div class="input-with-icon">
                                <i class="fas fa-lock"></i>
                                <input type="password" id="new-password" placeholder="Enter new password" name="first" required>
                                <button type="button" class="toggle-password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm-password">Confirm New Password</label>
                            <div class="input-with-icon">
                                <i class="fas fa-lock"></i>
                                <input type="password" id="confirm-password" placeholder="Re-type new password" name="second" required>
                                <button type="button" class="toggle-password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <button type="submit" class="submit-btn">Change Password</button>
                    </form>
                </div>
            </div>
        </main>

        <!-- Footer (same as other pages) -->
        <footer class="footer">
            <div class="footer-container">
                <p>&copy; 2023 Virtual Learning Environment</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </footer>
    </div>

    <script>
        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', function() {
                const input = this.parentNode.querySelector('input');
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });
    </script>
</body>
</html>