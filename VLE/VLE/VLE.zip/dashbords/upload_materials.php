<?php
session_start();
if(!isset($_SESSION["role"]) || $_SESSION["role"] != "staff") {
    header("Location: ../index.php");
    exit;
}

$course_id = $_GET['course_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Materials</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="page-container">

    <nav class="main-nav">
        <div class="nav-container">
            <div class="nav-brand">
                <i class="fas fa-graduation-cap"></i>
                <span>University VLE</span>
            </div>
            <div class="nav-right">
                <a href="course_view.php?course_id=<?php echo $course_id; ?>" class="back-btn">
                    <i class="fas fa-arrow-left"></i> Back to Course
                </a>
            </div>
        </div>
    </nav>

    <main class="main-content">
        <h2 class="dashboard-title">Upload Materials</h2>
        <div class="password-container">
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="material">Select File:</label>
                    <input type="file" name="material" class="form-control" required>
                </div>
                <button type="submit" class="submit-btn"><i class="fas fa-upload"></i> Upload</button>
            </form>
        </div>
    </main>

    <footer class="main-footer">
        <div class="footer-container">
            <p>&copy; 2025 University VLE System. All rights reserved.</p>
        </div>
    </footer>

</div>
</body>
</html>
