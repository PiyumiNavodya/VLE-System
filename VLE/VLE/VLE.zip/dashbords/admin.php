<?php
session_start();
if(!isset($_SESSION["role"]) || $_SESSION["role"] != "admin") {
    header("Location: ../index.php");
    exit;
}
include "../php/sys.php";
if(!is_active($_SESSION["username"])){
    header("Location: ../index.php?error=session_expired");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University VLE - Admin Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="body">
    <div class="min-h-screen">
        <!-- Navigation -->
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <i class="fas fa-graduation-cap"></i>
                    <span>University VLE</span>
                </div>
                <div class="nav-items">
                    <button id="logout-btn" class="logout-btn">
                        <a href="<?php echo "../php/logout.php"; ?>" style="text-decoration:none">Logout</a>
                    </button>
                    <div class="user-profile">
                        <span id="admin-name">Admin User</span>
                        <div class="user-avatar">AD</div>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <div class="header-section">
                <h2>Admin Dashboard</h2>
                <button id="change-password-btn" class="change-password-btn">
                    <i class="fas fa-key"></i> Change Password
                </button>
            </div>
            
            <div class="cards-container">
                <!-- User Management Card -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon purple-icon">
                            <i class="fas fa-users-cog"></i>
                        </div>
                        <h3>Manage Users</h3>
                    </div>
                    <p>Add, edit, and delete user accounts and permissions.</p>
                    <a href="manageUsers.php" class="card-button">
                        Manage Users <i class="fas fa-arrow-right"></i>
                    </a>
                </div>

                <!-- Course Management Card -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon indigo-icon">
                            <i class="fas fa-book"></i>
                        </div>
                        <h3>Manage Courses</h3>
                    </div>
                    <p>Add, edit courses and assign instructors.</p>
                    <a href="managecourses.php" class="card-button">
                        Manage Courses <i class="fas fa-arrow-right"></i>
                    </a>
                </div>

                <!-- Schedule Management Card -->
                
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon blue-icon">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                        <h3>Schedule Management</h3>
                    </div>
                    <p>Manage timetables and room assignments.</p>
                    <button class="card-button" >
                        <a href="schedule_management.php" class="card-button">Manage Schedules <i class="fas fa-arrow-right"></i></a>
                    </button>
                </div>

                <!-- Approve Registrations Card -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon pink-icon">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <h3>Approve Registrations</h3>
                    </div>
                    <p>View pending requests and approve/reject.</p>
                    <a href="requests.php" class="card-button">
                        Review Requests <i class="fas fa-arrow-right"></i>
                    </a>
                </div>

                <!-- Announcements Card -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon yellow-icon">
                            <i class="fas fa-bullhorn"></i>
                        </div>
                        <h3>Announcements</h3>
                    </div>
                    <p>Post and view important announcements for all users.</p>
                    <a href="anousment.php" class="card-button">
                        Go to Announcements <i class="fas fa-arrow-right"></i>
                    </a>
                </div>

                <!-- System Stats Card -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon teal-icon">
                            <i class="fas fa-chart-pie"></i>
                        </div>
                        <h3>System Stats</h3>
                    </div>
                    <p>View overview widgets and key metrics.</p>
                    <button class="card-button">
                        <a href="system_stats.php" class="card-button">View Stats <i class="fas fa-arrow-right"></i></a>
                    </button>
                </div>
            </div>
        </main>

        <!-- Footer -->
        <footer class="footer">
            <div class="footer-container">
                <p>&copy; 2023 University VLE System. All rights reserved.</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </footer>
    </div>

    <script>
        // Change password button
        document.getElementById('change-password-btn').addEventListener('click', () => {
            window.location.href = 'change-password.html?user=admin';
        });
    </script>
</body>
</html>