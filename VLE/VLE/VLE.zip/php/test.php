<?php
    $passwd=password_hash("123",PASSWORD_DEFAULT);
    echo "hash: ".$passwd."|";
?>